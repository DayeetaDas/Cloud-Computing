/* MODULE CODE: COMP30231
   MODULE NAME: SERVICE CENTRIC & CLOUD COMP 202021 FULL YEAR
   NTU ID: N0830182
   NAME: DAYEETA DAS
   MARSHALLING THE DATA.XML FILE WITH THE INFORMATION PLACED IN IT BASED ON THE COMPANY.XSD SCHEMA.
*/
//all the necessary header files gets included
import java.io.File; 
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import sharesOrder.*;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        sharesOrder.Company input = new sharesOrder.Company(); //define object type for the Company type
        List<SharePrice> values = input.getShareDetails(); //define a list for storing objects of SharePrice type
        //assign values
        input.setCompanyName("International Business Machine");
        input.setCompanySymbol("IBM");
        input.setSharesNo(1400);
        
        SharePrice s; //create new SharePrice object
        s = new SharePrice();
        s.setCurrency("USD");
        s.setValue((float)38000.8);
        s.setLastUpdate("02-01-2021");
        values.add(s);
        
        s = new SharePrice();
        s.setCurrency("USD");
        s.setValue((float)45678.67);
        s.setLastUpdate("03-01-2021");
        values.add(s);
        
        s = new SharePrice();
        s.setCurrency("USD");
        s.setValue((float)407896.15);
        s.setLastUpdate("04-01-2021");
        values.add(s);
        
        s = new SharePrice();
        s.setCurrency("USD");
        s.setValue((float)158767.6);
        s.setLastUpdate("05-01-2021");
        values.add(s);
        //marshall the data.xml file
        try {            
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(s.getClass().getPackage().getName());
            javax.xml.bind.Marshaller marshaller = jaxbCtx.createMarshaller();
            marshaller.setProperty(javax.xml.bind.Marshaller.JAXB_ENCODING, "UTF-8"); //NOI18N
            marshaller.setProperty(javax.xml.bind.Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            
            File file = new File("data.xml");
            //marshaller.marshal(input, System.out);
            marshaller.marshal(input,file);
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
    }

}
