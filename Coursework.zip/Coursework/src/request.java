/* MODULE CODE: COMP30231
   MODULE NAME: SERVICE CENTRIC & CLOUD COMP 202021 FULL YEAR
   NTU ID: N0830182
   NAME: DAYEETA DAS
   UNMARSHALLING THE DATA.XML FILE WITH THE INFORMATION PLACED IN IT BASED ON THE COMPANY.XSD SCHEMA.
*/
import sharesOrder.*; //importing the sharesOrder package

public class request {
    public static void main(String[] args){
        
        Company input = new Company();//create an object of the type Company
        //unmarshall the data.xml file.
        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(input.getClass().getPackage().getName());
            javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            input = (Company) unmarshaller.unmarshal(new java.io.File("C:\\Users\\Dayeeta\\Downloads\\Coursework\\data.xml")); //NOI18N
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
    }
    
}
