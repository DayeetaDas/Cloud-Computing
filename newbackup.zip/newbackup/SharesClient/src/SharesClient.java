/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author N0830182
 */
import java.io.*;
import java.net.*;
import java.util.*;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import org.netbeans.xml.schema.company.SharePrice;
public class SharesClient {

    /**
     * @param args the command line arguments
     */
    static String json = "...";
    public static void main(String[] args) throws FileNotFoundException{
        // TODO code application logic here
        System.out.println("[1] List all share details");
        System.out.println("[2] List highest share details");
        System.out.println("[3] List share details for dollar");
        System.out.println("[4] List share details for dinar");
        System.out.println("[5] List share details for pounds");
        System.out.println("[6] List share details for rupees");
        System.out.println("[7] Display currency codes for different currencies");
        System.out.println("[8] Convert shareprice rate to preferred rate");
        System.out.println("[9] Return the latest share value quote");
        Scanner sc = new Scanner(System.in);
        int choice = 0;
        choice = sc.nextInt();
        switch(choice){
            case 1:{
                List<org.netbeans.xml.schema.company.SharePrice> list = getAllShares();
                Iterator itr = list.iterator();
                SharePrice nextData;
                while(itr.hasNext()){
                    
                   nextData = (SharePrice) itr.next();
                   System.out.println("Currency:"+nextData.getCurrency());
                   System.out.println("Value:"+nextData.getValue());
                   System.out.println("last Date:"+nextData.getLastUpdate());
                }
                break;
            }
            case 2:{
                
                List<org.netbeans.xml.schema.company.SharePrice> list = listHighestShareDetails();
                Iterator itr = list.iterator();
                SharePrice nextData;
                int size = list.size();
                List<Float> values = new ArrayList<Float>();
                List<String> currencies = new ArrayList<String>();
                List<String> dates = new ArrayList<String>();
                float Value = 0; String Currency = "", LastUpdate = "";

                List<SharePrice> highest = new ArrayList<SharePrice>();
                SharePrice s;
                 while(itr.hasNext()){
                        nextData = (SharePrice) itr.next();
                        values.add(nextData.getValue());
                        currencies.add(nextData.getCurrency());
                        dates.add(nextData.getLastUpdate());
                    }
                        float max = Collections.max(values);
                        int counter = 0;
                        for(int i= 0; i < size; i++)
                        {
                            if(values.get(i).equals(max))
                            {
                                counter = i;
                            }
                        }
                Value = values.get(counter);
                Currency = currencies.get(counter);
                LastUpdate = dates.get(counter);
                s = new SharePrice();
                s.setValue(Value);
                s.setCurrency(Currency);
                s.setLastUpdate(LastUpdate);
                highest.add(s);
                
                Iterator itr2 = highest.iterator();
                while(itr2.hasNext())
                    {
                        nextData = (SharePrice) itr2.next();
                        System.out.println(nextData.getCurrency());
                        System.out.println(nextData.getValue());
                        System.out.println(nextData.getLastUpdate());
                    } 
                break;
            }
            case 3:{
                
                List<org.netbeans.xml.schema.company.SharePrice> list = listDetailsForDollar();
                Iterator itr = list.iterator();
                SharePrice nextData;
                int size = list.size();
                List<Float> values = new ArrayList<Float>();
                List<String> currencies = new ArrayList<String>();
                List<String> dates = new ArrayList<String>();
                float Value = 0; String Currency = "", LastUpdate = "";

                List<SharePrice> dollar = new ArrayList<SharePrice>();
                SharePrice s;
                 while(itr.hasNext()){
                        nextData = (SharePrice) itr.next();
                        values.add(nextData.getValue());
                        currencies.add(nextData.getCurrency());
                        dates.add(nextData.getLastUpdate());
                    }
                        int counter = 0;
                        for(int i= 0; i < size; i++)
                        {
                            if(currencies.get(i).equalsIgnoreCase("Dollar"))
                            {
                                counter = i;
                            }
                        }
                Value = values.get(counter);
                Currency = currencies.get(counter);
                LastUpdate = dates.get(counter);
                s = new SharePrice();
                s.setValue(Value);
                s.setCurrency(Currency);
                s.setLastUpdate(LastUpdate);
                dollar.add(s);
                
                Iterator itr2 = dollar.iterator();
                while(itr2.hasNext())
                    {
                        nextData = (SharePrice) itr2.next();
                        System.out.println(nextData.getCurrency());
                        System.out.println(nextData.getValue());
                        System.out.println(nextData.getLastUpdate());
                    } 
                break;

            }
            case 4:{
                
                List<org.netbeans.xml.schema.company.SharePrice> list = listDetailsForDinar();
                Iterator itr = list.iterator();
                SharePrice nextData;
                int size = list.size();
                List<Float> values = new ArrayList<Float>();
                List<String> currencies = new ArrayList<String>();
                List<String> dates = new ArrayList<String>();
                float Value = 0; String Currency = "", LastUpdate = "";

                List<SharePrice> dinar = new ArrayList<SharePrice>();
                SharePrice s;
                 while(itr.hasNext()){
                        nextData = (SharePrice) itr.next();
                        values.add(nextData.getValue());
                        currencies.add(nextData.getCurrency());
                        dates.add(nextData.getLastUpdate());
                    }
                        int counter = 0;
                        for(int i= 0; i < size; i++)
                        {
                            if(currencies.get(i).equalsIgnoreCase("Dinar"))
                            {
                                counter = i;
                            }
                        }
                Value = values.get(counter);
                Currency = currencies.get(counter);
                LastUpdate = dates.get(counter);
                s = new SharePrice();
                s.setValue(Value);
                s.setCurrency(Currency);
                s.setLastUpdate(LastUpdate);
                dinar.add(s);
                
                Iterator itr2 = dinar.iterator();
                while(itr2.hasNext())
                    {
                        nextData = (SharePrice) itr2.next();
                        System.out.println(nextData.getCurrency());
                        System.out.println(nextData.getValue());
                        System.out.println(nextData.getLastUpdate());
                    } 
                break;
            }
            case 5:{
                
                List<org.netbeans.xml.schema.company.SharePrice> list = listDetailsForPounds();
                Iterator itr = list.iterator();
                SharePrice nextData;
                int size = list.size();
                List<Float> values = new ArrayList<Float>();
                List<String> currencies = new ArrayList<String>();
                List<String> dates = new ArrayList<String>();
                float Value = 0; String Currency = "", LastUpdate = "";

                List<SharePrice> pounds = new ArrayList<SharePrice>();
                SharePrice s;
                 while(itr.hasNext()){
                        nextData = (SharePrice) itr.next();
                        values.add(nextData.getValue());
                        currencies.add(nextData.getCurrency());
                        dates.add(nextData.getLastUpdate());
                    }
                        int counter = 0;
                        for(int i= 0; i < size; i++)
                        {
                            if(currencies.get(i).equalsIgnoreCase("Pounds"))
                            {
                                counter = i;
                            }
                        }
                Value = values.get(counter);
                Currency = currencies.get(counter);
                LastUpdate = dates.get(counter);
                s = new SharePrice();
                s.setValue(Value);
                s.setCurrency(Currency);
                s.setLastUpdate(LastUpdate);
                pounds.add(s);
                
                Iterator itr2 = pounds.iterator();
                while(itr2.hasNext())
                    {
                        nextData = (SharePrice) itr2.next();
                        System.out.println(nextData.getCurrency());
                        System.out.println(nextData.getValue());
                        System.out.println(nextData.getLastUpdate());
                    } 
                break;
            }
            case 6:{
                
                List<org.netbeans.xml.schema.company.SharePrice> list = listDetailsForRupees();
                Iterator itr = list.iterator();
                SharePrice nextData;
                int size = list.size();
                List<Float> values = new ArrayList<Float>();
                List<String> currencies = new ArrayList<String>();
                List<String> dates = new ArrayList<String>();
                float Value = 0; String Currency = "", LastUpdate = "";

                List<SharePrice> rupees = new ArrayList<SharePrice>();
                SharePrice s;
                 while(itr.hasNext()){
                        nextData = (SharePrice) itr.next();
                        values.add(nextData.getValue());
                        currencies.add(nextData.getCurrency());
                        dates.add(nextData.getLastUpdate());
                    }
                        int counter = 0;
                        for(int i= 0; i < size; i++)
                        {
                            if(currencies.get(i).equalsIgnoreCase("Rupees"))
                            {
                                counter = i;
                            }
                        }
                Value = values.get(counter);
                Currency = currencies.get(counter);
                LastUpdate = dates.get(counter);
                s = new SharePrice();
                s.setValue(Value);
                s.setCurrency(Currency);
                s.setLastUpdate(LastUpdate);
                rupees.add(s);
                
                Iterator itr2 = rupees.iterator();
                while(itr2.hasNext())
                    {
                        nextData = (SharePrice) itr2.next();
                        System.out.println(nextData.getCurrency());
                        System.out.println(nextData.getValue());
                        System.out.println(nextData.getLastUpdate());
                    } 
                break;
            }
            case 7:{
                
                List<java.lang.String> list = getCurrencyCodes();
                Iterator itr = list.iterator();
                java.lang.String nextcode;
                while(itr.hasNext()){
                    
                    nextcode = (java.lang.String) itr.next();
                    System.out.println(nextcode);
                }
                break;
            }
            case 8:{
               
                String curr1, curr2;
                System.out.println("Enter the current currency code and the code you want to change to:");
                sc.nextLine();
                double result = getConversionRate(curr1 = sc.nextLine(), curr2 = sc.nextLine());
                System.out.println("Current Rate:"+result);
                break;
            }
            case 9:{
                
                try {
                    URL url = new URL("https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=ibm&interval=5min&apikey=C53IS6PCLKAYBX9L");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    // Check for successful response code or throw error
                    if (conn.getResponseCode() != 200) {
                    throw new IOException(conn.getResponseMessage());
                    }
                        BufferedReader ins = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        String inString;
                        StringBuilder sb = new StringBuilder();
                        while ((inString = ins.readLine()) != null) {
                        sb.append(inString);
                   }
                        FileWriter file=new FileWriter("H:\\Cloud Computing\\quotes.txt");    
                        file.write(sb.toString());    
                        file.close();
                        FileReader readfile = new FileReader("H:\\Cloud Computing\\quotes.txt");
                        Scanner fr = new Scanner(readfile);
                        String quote = "";
                        int length = sb.toString().length();
                        for(int i = 1; i<length; i++){
                            if(i>9 && i < 17){
                            quote = fr.nextLine();
                            System.out.println(quote);
                            }else{
                                sc.nextLine();
                            }
                        }
                        ins.close();
                }
                    catch (MalformedURLException me) {
                   System.out.println("MalformedURLException: " + me); }
                    catch (Exception ioe) {
                    System.out.println("Exception: " + ioe); }
               
                break;
            }
            default:
                System.out.println("There is no such option");
                break;
        }
    }

    private static java.util.List<org.netbeans.xml.schema.company.SharePrice> getAllShares() {
        org.myws.SharesWebService_Service service = new org.myws.SharesWebService_Service();
        org.myws.SharesWebService port = service.getSharesWebServicePort();
        return port.getAllShares();
    }

    private static java.util.List<org.netbeans.xml.schema.company.SharePrice> listHighestShareDetails() {
        org.myws.SharesWebService_Service service = new org.myws.SharesWebService_Service();
        org.myws.SharesWebService port = service.getSharesWebServicePort();
        return port.listHighestShareDetails();
    }

    private static java.util.List<org.netbeans.xml.schema.company.SharePrice> listDetailsForDollar() {
        org.myws.SharesWebService_Service service = new org.myws.SharesWebService_Service();
        org.myws.SharesWebService port = service.getSharesWebServicePort();
        return port.listDetailsForDollar();
    }

    private static java.util.List<org.netbeans.xml.schema.company.SharePrice> listDetailsForDinar() {
        org.myws.SharesWebService_Service service = new org.myws.SharesWebService_Service();
        org.myws.SharesWebService port = service.getSharesWebServicePort();
        return port.listDetailsForDinar();
    }

    private static java.util.List<org.netbeans.xml.schema.company.SharePrice> listDetailsForPounds() {
        org.myws.SharesWebService_Service service = new org.myws.SharesWebService_Service();
        org.myws.SharesWebService port = service.getSharesWebServicePort();
        return port.listDetailsForPounds();
    }

    private static java.util.List<org.netbeans.xml.schema.company.SharePrice> listDetailsForRupees() {
        org.myws.SharesWebService_Service service = new org.myws.SharesWebService_Service();
        org.myws.SharesWebService port = service.getSharesWebServicePort();
        return port.listDetailsForRupees();
    }

    private static java.util.List<java.lang.String> getCurrencyCodes() {
        docwebservices.CurrencyConversionWSService service = new docwebservices.CurrencyConversionWSService();
        docwebservices.CurrencyConversionWS port = service.getCurrencyConversionWSPort();
        return port.getCurrencyCodes();
    }

    private static double getConversionRate(java.lang.String arg0, java.lang.String arg1) {
        docwebservices.CurrencyConversionWSService service = new docwebservices.CurrencyConversionWSService();
        docwebservices.CurrencyConversionWS port = service.getCurrencyConversionWSPort();
        return port.getConversionRate(arg0, arg1);
    }
    
}
