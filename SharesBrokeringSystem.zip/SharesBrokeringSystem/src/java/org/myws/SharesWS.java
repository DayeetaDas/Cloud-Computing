/* MODULE CODE: COMP30231
   MODULE NAME: SERVICE CENTRIC & CLOUD COMP 202021 FULL YEAR
   NTU ID: N0830182
   NAME: DAYEETA DAS
   CREATING THE SHARES BROKERING WEB SERVICE. THE PRE-CODED CURRENCY CONVERION WEB SERVICE
   HAS BEEN CONSUMED AS A .JAR FILE IN THE LIBRARY. AN EXTERNAL REST API HAS BEEN CONSUMED
   TO GET THE LATEST SHARE QUOTE. A SELF-MADE REST API HAS BEEN CREATED AND CONSUMED TO GET
   THE QUOTE AT EVERY INSTANCE.
*/
package org.myws;
//necessary header files are included
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import sharesOrder.*;
import java.util.*;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.ejb.Stateless;


@WebService(serviceName = "SharesWS")
@Stateless()
public class SharesWS { //SharesWS class has been defined.

    
    DOCwebServices.CurrencyConversionWS cc = new DOCwebServices.CurrencyConversionWS();
    
    @WebMethod(operationName = "getAllShareDetails") // a function to read all the share details from the data.xml file 
    public List<Object> getAllShareDetails() {
        
        sharesOrder.Company input = new sharesOrder.Company();
        
        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(input.getClass().getPackage().getName());
            javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            input = (Company) unmarshaller.unmarshal(new java.io.File("C:\\Users\\Dayeeta\\Downloads\\Coursework\\data.xml")); //NOI18N
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
        
        List<SharePrice> list = input.getShareDetails();
        SharePrice nextData;
        
        Iterator itr = list.iterator();
        
        List<Object> CompanyDetails = new ArrayList<Object>();
        
        CompanyDetails.add(input.getCompanyName());
        CompanyDetails.add(input.getCompanySymbol());
        CompanyDetails.add(input.getSharesNo());
        
        while(itr.hasNext()){
            
            nextData = (SharePrice) itr.next();
            CompanyDetails.add(nextData.getCurrency());
            CompanyDetails.add(nextData.getValue());
            CompanyDetails.add(nextData.getLastUpdate());
        }
        
        return CompanyDetails;
    }
    
    @WebMethod(operationName = "getHighestShareDetails")//function for searching and reading the details of the highest share price
    public List<Object> getHighestShareDetails(){
        
        sharesOrder.Company input = new sharesOrder.Company();
        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(input.getClass().getPackage().getName());
            javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            input = (Company) unmarshaller.unmarshal(new java.io.File("C:\\Users\\Dayeeta\\Downloads\\Coursework\\data.xml")); //NOI18N
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
        
        List<SharePrice> list = input.getShareDetails();
        SharePrice nextData;
        
        Iterator itr = list.iterator();
        
        List<Object> CompanyDetails = new ArrayList<Object>();
        
        CompanyDetails.add(input.getCompanyName());
        CompanyDetails.add(input.getCompanySymbol());
        CompanyDetails.add(input.getSharesNo());
        
        List<String> currencies = new ArrayList<String>();
        List<Double> values = new ArrayList<Double>();
        List<String> dates = new ArrayList<String>();
        
        while(itr.hasNext()){
            
            nextData = (SharePrice) itr.next();
            currencies.add(nextData.getCurrency());
            values.add(nextData.getValue());
            dates.add(nextData.getLastUpdate());
        }
        
        double max = Collections.max(values); int counter = 0;
        //linear search has been performed to get the counter for the highest price
        for(int i = 0; i<values.size(); i++){
            
            if(values.get(i) == max)
                
                counter = i;
        }
        CompanyDetails.add(currencies.get(counter));
        CompanyDetails.add(values.get(counter));
        CompanyDetails.add(dates.get(counter));
        
        return CompanyDetails;
    }
    
    @WebMethod(operationName = "getLatestShareDetails")//function for searching and reading the details of the latest share price
    public List<Object> getLatestShareDetails(){
        
        sharesOrder.Company input = new sharesOrder.Company();
        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(input.getClass().getPackage().getName());
            javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            input = (Company) unmarshaller.unmarshal(new java.io.File("C:\\Users\\Dayeeta\\Downloads\\Coursework\\data.xml")); //NOI18N
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
        
        List<SharePrice> list = input.getShareDetails();
        SharePrice nextData;
        
        Iterator itr = list.iterator();
        
        List<Object> CompanyDetails = new ArrayList<Object>();
        
        CompanyDetails.add(input.getCompanyName());
        CompanyDetails.add(input.getCompanySymbol());
        CompanyDetails.add(input.getSharesNo());
        
        List<String> currencies = new ArrayList<String>();
        List<Double> values = new ArrayList<Double>();
        List<String> dates = new ArrayList<String>(); 
        
        while(itr.hasNext()){
            
            nextData = (SharePrice) itr.next();
            currencies.add(nextData.getCurrency());
            values.add(nextData.getValue());
            dates.add(nextData.getLastUpdate());
        }
        
        String max = Collections.max(dates);int counter = 0;
        //linear search for finding the counter of the latest date
        for(int i = 0; i< dates.size(); i++){
            
            if(dates.get(i) == max)
                counter = i;
        }
        CompanyDetails.add(currencies.get(counter));
        CompanyDetails.add(values.get(counter));
        CompanyDetails.add(dates.get(counter));
        
        return CompanyDetails;
    }
    
    @WebMethod(operationName = "UpdateShareDetails")//function to update shares on offer when a purchase is made
    public List<Object> UpdateShareDetails(int number){ //input is taken for the number of shares to be purchased
        
         sharesOrder.Company input = new sharesOrder.Company();
         try {
             javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(input.getClass().getPackage().getName());
             javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
             input = (Company) unmarshaller.unmarshal(new java.io.File("C:\\Users\\Dayeeta\\Downloads\\Coursework\\data.xml")); //NOI18N
         } catch (javax.xml.bind.JAXBException ex) {
             // XXXTODO Handle exception
             java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
         }
         
         List<Object> CompanyDetails = new ArrayList<Object>();
        
        CompanyDetails.add(input.getCompanyName());
        CompanyDetails.add(input.getCompanySymbol());
        
        
        int current = input.getSharesNo();
        
        int update = current - number; //the remaining number of shares is updated
        
        CompanyDetails.add(update);
        
        return CompanyDetails;
    }
    
    @WebMethod(operationName = "getCurrencyCodes")//function to read the currency codes from the consumed CurrencyConversionWS
    public List<String> getCurrencyCodes(){
        
        List<String> list = new ArrayList<String>();
        list = cc.GetCurrencyCodes();
        return list;
    }
    
    @WebMethod(operationName = "ChangeCurrency")//function to convert currency to required rate
    public List<Double> ChangeCurrency(String curr1, String curr2){//input for the current currency and the currency to be converted to is taken
        
       sharesOrder.Company input = new sharesOrder.Company();
        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(input.getClass().getPackage().getName());
            javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            input = (Company) unmarshaller.unmarshal(new java.io.File("C:\\Users\\Dayeeta\\Downloads\\Coursework\\data.xml")); //NOI18N
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
        
        List<SharePrice> list = input.getShareDetails();
        SharePrice nextData;
        
        Iterator itr = list.iterator();
        
        List<Object> CompanyDetails = new ArrayList<Object>();
        
        CompanyDetails.add(input.getCompanyName());
        CompanyDetails.add(input.getCompanySymbol());
        CompanyDetails.add(input.getSharesNo());
        
        List<String> currencies = new ArrayList<String>();
        List<Double> values = new ArrayList<Double>();
        List<String> dates = new ArrayList<String>(); 
        
        while(itr.hasNext()){
            
            nextData = (SharePrice) itr.next();
            currencies.add(nextData.getCurrency());
            values.add(nextData.getValue());
            dates.add(nextData.getLastUpdate());
        }
        
        double rate = cc.GetConversionRate(curr2, curr1);
        List<Double> new_values = new ArrayList<Double>();
        for(int i = 0; i<values.size(); i++){
            
            new_values.add(values.get(i) * rate);//the available share prices is converted to the required currency 
        }
        
        return new_values;
    }
    
    @WebMethod(operationName = "GetQuote")//function for reading the latest share value quote from a json file
    public String getQuote(){
        
        String quote = " ";
        
        try {
                    URL url = new URL("https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=ibm&interval=5min&apikey=C53IS6PCLKAYBX9L");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    // Check for successful response code or throw error
                    if (conn.getResponseCode() != 200) {
                    throw new IOException(conn.getResponseMessage());
                    }
                        BufferedReader ins = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        String inString;
                        StringBuilder sb = new StringBuilder();
                        while ((inString = ins.readLine()) != null) {
                        sb.append(inString + "\n");
                   }
                        FileWriter file=new FileWriter("C:\\Users\\Dayeeta\\Downloads\\quotes.json");    
                        file.write(sb.toString());    
                        file.close();
                        Map<String, Object> resultMap = new ObjectMapper().readValue(new File(
                    "C:\\Users\\Dayeeta\\Downloads\\quotes.json"), new com.fasterxml.jackson.core.type.TypeReference<Map<String, Object>>() {
                    });
                    //json file is broken down into objects
                    Map<String, Object> mainMap = (Map<String, Object>)resultMap.get("Time Series (5min)");
                    Map<String, Object> timeMap = (Map<String, Object>)resultMap.get("Meta Data");
                    String time = timeMap.get("3. Last Refreshed").toString();
                         quote= (mainMap.get(time).toString());
                        return quote; //latest share value quote is returned
                        //ins.close();
                }
                    catch (MalformedURLException me) {
                   System.out.println("MalformedURLException: " + me); }
                    catch (Exception ioe) {
                    return ("Exception: " + ioe); }
               
               return quote;
    }
    
    @WebMethod(operationName = "GenerateLatestShareRate")//function for getting latest share price in other currencies from self-made REST API
    public String GenerateLatestShareRate(){
        
        String latest_price = " ";
        try {
                    URL url = new URL("http://localhost:17445/Update/webresources/update");//URL for the self-made REST API
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    // Check for successful response code or throw error
                    if (conn.getResponseCode() != 200) {
                    throw new IOException(conn.getResponseMessage());
                    }
                        BufferedReader ins = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        String inString;
                        StringBuilder sb = new StringBuilder();
                        while ((inString = ins.readLine()) != null) {
                        sb.append(inString + "\n");
                   }
                        FileWriter file=new FileWriter("C:\\Users\\Dayeeta\\Downloads\\latest_price.txt");    
                        file.write(sb.toString());    
                        file.close();
                        BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\Dayeeta\\Downloads\\latest_price.txt"));
                        StringBuilder stringBuilder = new StringBuilder();
                        String line = null;
                        String ls = System.getProperty("line.separator");
                        while ((line = reader.readLine()) != null) {
                                stringBuilder.append(line);
                                stringBuilder.append(ls);
                    }
                    // delete the last new line separator
                    stringBuilder.deleteCharAt(stringBuilder.length() - 1);
                    reader.close();
                    latest_price = stringBuilder.toString();
                }
                    catch (MalformedURLException me) {
                   System.out.println("MalformedURLException: " + me); }
                    catch (Exception ioe) {
                    return ("Exception: " + ioe); }
                    

                    
               
        return latest_price;
    }
    
}
