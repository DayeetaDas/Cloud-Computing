/* MODULE CODE: COMP30231
   MODULE NAME: SERVICE CENTRIC & CLOUD COMP 202021 FULL YEAR
   NTU ID: N0830182
   NAME: DAYEETA DAS
   CREATING A REST API FOR UPDATING THE LATEST SHARE PRICE TO OTHER CURRENCY RATES
*/
package updateRest;
//all the necessary header files are included
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


@Path("update")
public class Update {

    @Context
    private UriInfo context;

    
    public Update() {
    }

    
    @GET
    @Produces(MediaType.TEXT_PLAIN)//the response is generated in a plain text format
    public String getConvertedRates() {//function for updating latest share price to other currency rates
        
        StringBuilder sb = new StringBuilder();
        sb.append("Latest Share Price updated to other currencies:");
        sb.append("\n");
        double latest_price = 158767.6; sb.append("AED: ");
        double AED = 3.67 * latest_price;sb.append(AED);sb.append("\n");
        double ARS = 86.39 * latest_price;sb.append("ARS: "); sb.append(ARS); sb.append("\n");
        double AUD = 1.30 * latest_price; sb.append("AUD: "); sb.append(AUD); sb.append("\n");
        double BGN = 1.61 * latest_price; sb.append("BGN: "); sb.append(BGN); sb.append("\n");
        double BRL = 5.47 * latest_price;sb.append("BRL: "); sb.append(BRL); sb.append("\n");
        double BWP = 10.92 * latest_price;sb.append("BWP: "); sb.append(BWP); sb.append("\n");
        double CAD = 1.27 * latest_price;sb.append("CAD: "); sb.append(CAD); sb.append("\n");
        double CHF = 0.89 * latest_price;sb.append("CHF: "); sb.append(CHF); sb.append("\n");
        double CLP = 727.38 * latest_price;sb.append("CLP: "); sb.append(CLP); sb.append("\n");
        double CNY = 6.48 * latest_price;sb.append("CNY: "); sb.append(CNY); sb.append("\n");
        double COP = 3525.58 * latest_price;sb.append("COP: "); sb.append(COP); sb.append("\n");
        double DKK = 6.11 * latest_price;sb.append("DKK: "); sb.append(DKK); sb.append("\n");
        double EGP = 15.68 * latest_price;sb.append("EGP: "); sb.append(EGP); sb.append("\n");
        double EUR = 0.82 * latest_price;sb.append("EUR: "); sb.append(EUR); sb.append("\n");
        double GBP = latest_price * 0.73;sb.append("GBP: "); sb.append(GBP); sb.append("\n");
        double HKD = 7.75 * latest_price;sb.append("HKD: "); sb.append(HKD); sb.append("\n");
        double HRK = 6.22 * latest_price;sb.append("HRK: "); sb.append(HRK); sb.append("\n");
        double HUF = 293.64 * latest_price;sb.append("HUF: "); sb.append(HUF); sb.append("\n");
        double ILS = 3.27 * latest_price;sb.append("ILS: "); sb.append(ILS); sb.append("\n");
        double INR = 72.98 * latest_price;sb.append("INR: "); sb.append(INR); sb.append("\n");
        double ISK = 128.97 * latest_price;sb.append("ISK: "); sb.append(ISK); sb.append("\n");
        double JPY = 103.77 * latest_price;sb.append("JPY: "); sb.append(JPY); sb.append("\n");
        double KRW = 1105.41 * latest_price;sb.append("KRW: "); sb.append(KRW); sb.append("\n");
        double KZT = 420.57 * latest_price;sb.append("KZT: "); sb.append(KZT); sb.append("\n");
        double LKR = 197.00 * latest_price;sb.append("LKR: "); sb.append(LKR); sb.append("\n");
        double LTL = 2.95 * latest_price;sb.append("LTL: "); sb.append(LTL); sb.append("\n");
        double LYD = 4.45 * latest_price;sb.append("LYD: "); sb.append(LYD); sb.append("\n");
        double MXN = 19.96 * latest_price;sb.append("MXN: "); sb.append(MXN); sb.append("\n");
        double MYR = 4.04 * latest_price;sb.append("MYR: "); sb.append(MYR); sb.append("\n");
        double NOK = 18.50 * latest_price;sb.append("NOK: "); sb.append(NOK); sb.append("\n");
        double NPR = 116.76 * latest_price;sb.append("NPR: "); sb.append(NPR); sb.append("\n");
        double NZD = 1.39 * latest_price;sb.append("NZD: "); sb.append(NZD); sb.append("\n");
        double OMR = 0.38 * latest_price;sb.append("OMR: "); sb.append(OMR); sb.append("\n");
        double PKR = 160.35 * latest_price;sb.append("PKR: "); sb.append(PKR); sb.append("\n");
        double QAR = 3.64 * latest_price;sb.append("QAR: "); sb.append(QAR); sb.append("\n");
        double RON = 4.00 * latest_price;sb.append("RON: "); sb.append(RON); sb.append("\n");
        double RUB = 75.15 * latest_price;sb.append("RUB: "); sb.append(RUB); sb.append("\n");
        double SAR = 3.75 * latest_price;sb.append("SAR: "); sb.append(SAR); sb.append("\n");
        double SDG = 55.00 * latest_price;sb.append("SDG: "); sb.append(SDG); sb.append("\n");
        double SEK = 8.30 * latest_price;sb.append("SEK: "); sb.append(SEK); sb.append("\n");
        double SGD = 1.33 * latest_price;sb.append("SGD: "); sb.append(SGD); sb.append("\n");
        double THB = 29.96 * latest_price;sb.append("THB: "); sb.append(THB); sb.append("\n");
        double TRY = 7.41 * latest_price;sb.append("TRY: "); sb.append(TRY); sb.append("\n");
        double TTD = 6.75 * latest_price;sb.append("TTD: "); sb.append(TTD); sb.append("\n");
        double TWD = 27.95 * latest_price;sb.append("TWD: "); sb.append(TWD); sb.append("\n");
        double UAH = 28.15 * latest_price;sb.append("UAH: "); sb.append(UAH); sb.append("\n");
        double ZAR = 15.11 * latest_price;sb.append("ZAR: "); sb.append(ZAR); sb.append("\n");
        
        return sb.toString();
    }

    
    @PUT
    @Consumes(MediaType.TEXT_PLAIN)
    public void putText(String content) {
    }
}
