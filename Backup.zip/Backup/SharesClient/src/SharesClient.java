/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author N0830182
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import org.netbeans.xml.schema.company.SharePrice;
public class SharesClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("[1] List all share details");
        System.out.println("[2] List highest share details");
        System.out.println("[3] List share details for dollar");
        System.out.println("[4] List share details for dinar");
        System.out.println("[5] List share details for pounds");
        System.out.println("[6] List share details for rupees");
        Scanner sc = new Scanner(System.in);
        int choice = 0;
        choice = sc.nextInt();
        switch(choice){
            case 1:{
                List<org.netbeans.xml.schema.company.SharePrice> list = getAllShares();
                Iterator itr = list.iterator();
                SharePrice nextData;
                while(itr.hasNext()){
                    
                   nextData = (SharePrice) itr.next();
                   System.out.println("Currency:"+nextData.getCurrency());
                   System.out.println("Value:"+nextData.getValue());
                   System.out.println("last Date:"+nextData.getLastUpdate());
                }
                break;
            }
            case 2:{
                
                List<org.netbeans.xml.schema.company.SharePrice> list = listHighestShareDetails();
                Iterator itr = list.iterator();
                SharePrice nextData;
                int size = list.size();
                List<Float> values = new ArrayList<Float>();
                List<String> currencies = new ArrayList<String>();
                List<String> dates = new ArrayList<String>();
                float Value = 0; String Currency = "", LastUpdate = "";

                List<SharePrice> highest = new ArrayList<SharePrice>();
                SharePrice s;
                 while(itr.hasNext()){
                        nextData = (SharePrice) itr.next();
                        values.add(nextData.getValue());
                        currencies.add(nextData.getCurrency());
                        dates.add(nextData.getLastUpdate());
                    }
                        float max = Collections.max(values);
                        int counter = 0;
                        for(int i= 0; i < size; i++)
                        {
                            if(values.get(i).equals(max))
                            {
                                counter = i;
                            }
                        }
                Value = values.get(counter);
                Currency = currencies.get(counter);
                LastUpdate = dates.get(counter);
                s = new SharePrice();
                s.setValue(Value);
                s.setCurrency(Currency);
                s.setLastUpdate(LastUpdate);
                highest.add(s);
                
                Iterator itr2 = highest.iterator();
                while(itr2.hasNext())
                    {
                        nextData = (SharePrice) itr2.next();
                        System.out.println(nextData.getCurrency());
                        System.out.println(nextData.getValue());
                        System.out.println(nextData.getLastUpdate());
                    } 
                break;
            }
            case 3:{
                
                List<org.netbeans.xml.schema.company.SharePrice> list = listDetailsForDollar();
                Iterator itr = list.iterator();
                SharePrice nextData;
                int size = list.size();
                List<Float> values = new ArrayList<Float>();
                List<String> currencies = new ArrayList<String>();
                List<String> dates = new ArrayList<String>();
                float Value = 0; String Currency = "", LastUpdate = "";

                List<SharePrice> dollar = new ArrayList<SharePrice>();
                SharePrice s;
                 while(itr.hasNext()){
                        nextData = (SharePrice) itr.next();
                        values.add(nextData.getValue());
                        currencies.add(nextData.getCurrency());
                        dates.add(nextData.getLastUpdate());
                    }
                        int counter = 0;
                        for(int i= 0; i < size; i++)
                        {
                            if(currencies.get(i).equalsIgnoreCase("Dollar"))
                            {
                                counter = i;
                            }
                        }
                Value = values.get(counter);
                Currency = currencies.get(counter);
                LastUpdate = dates.get(counter);
                s = new SharePrice();
                s.setValue(Value);
                s.setCurrency(Currency);
                s.setLastUpdate(LastUpdate);
                dollar.add(s);
                
                Iterator itr2 = dollar.iterator();
                while(itr2.hasNext())
                    {
                        nextData = (SharePrice) itr2.next();
                        System.out.println(nextData.getCurrency());
                        System.out.println(nextData.getValue());
                        System.out.println(nextData.getLastUpdate());
                    } 
                break;

            }
            case 4:{
                
                List<org.netbeans.xml.schema.company.SharePrice> list = listDetailsForDinar();
                Iterator itr = list.iterator();
                SharePrice nextData;
                int size = list.size();
                List<Float> values = new ArrayList<Float>();
                List<String> currencies = new ArrayList<String>();
                List<String> dates = new ArrayList<String>();
                float Value = 0; String Currency = "", LastUpdate = "";

                List<SharePrice> dinar = new ArrayList<SharePrice>();
                SharePrice s;
                 while(itr.hasNext()){
                        nextData = (SharePrice) itr.next();
                        values.add(nextData.getValue());
                        currencies.add(nextData.getCurrency());
                        dates.add(nextData.getLastUpdate());
                    }
                        int counter = 0;
                        for(int i= 0; i < size; i++)
                        {
                            if(currencies.get(i).equalsIgnoreCase("Dinar"))
                            {
                                counter = i;
                            }
                        }
                Value = values.get(counter);
                Currency = currencies.get(counter);
                LastUpdate = dates.get(counter);
                s = new SharePrice();
                s.setValue(Value);
                s.setCurrency(Currency);
                s.setLastUpdate(LastUpdate);
                dinar.add(s);
                
                Iterator itr2 = dinar.iterator();
                while(itr2.hasNext())
                    {
                        nextData = (SharePrice) itr2.next();
                        System.out.println(nextData.getCurrency());
                        System.out.println(nextData.getValue());
                        System.out.println(nextData.getLastUpdate());
                    } 
                break;
            }
            case 5:{
                
                List<org.netbeans.xml.schema.company.SharePrice> list = listDetailsForPounds();
                Iterator itr = list.iterator();
                SharePrice nextData;
                int size = list.size();
                List<Float> values = new ArrayList<Float>();
                List<String> currencies = new ArrayList<String>();
                List<String> dates = new ArrayList<String>();
                float Value = 0; String Currency = "", LastUpdate = "";

                List<SharePrice> pounds = new ArrayList<SharePrice>();
                SharePrice s;
                 while(itr.hasNext()){
                        nextData = (SharePrice) itr.next();
                        values.add(nextData.getValue());
                        currencies.add(nextData.getCurrency());
                        dates.add(nextData.getLastUpdate());
                    }
                        int counter = 0;
                        for(int i= 0; i < size; i++)
                        {
                            if(currencies.get(i).equalsIgnoreCase("Pounds"))
                            {
                                counter = i;
                            }
                        }
                Value = values.get(counter);
                Currency = currencies.get(counter);
                LastUpdate = dates.get(counter);
                s = new SharePrice();
                s.setValue(Value);
                s.setCurrency(Currency);
                s.setLastUpdate(LastUpdate);
                pounds.add(s);
                
                Iterator itr2 = pounds.iterator();
                while(itr2.hasNext())
                    {
                        nextData = (SharePrice) itr2.next();
                        System.out.println(nextData.getCurrency());
                        System.out.println(nextData.getValue());
                        System.out.println(nextData.getLastUpdate());
                    } 
                break;
            }
            case 6:{
                
                List<org.netbeans.xml.schema.company.SharePrice> list = listDetailsForRupees();
                Iterator itr = list.iterator();
                SharePrice nextData;
                int size = list.size();
                List<Float> values = new ArrayList<Float>();
                List<String> currencies = new ArrayList<String>();
                List<String> dates = new ArrayList<String>();
                float Value = 0; String Currency = "", LastUpdate = "";

                List<SharePrice> rupees = new ArrayList<SharePrice>();
                SharePrice s;
                 while(itr.hasNext()){
                        nextData = (SharePrice) itr.next();
                        values.add(nextData.getValue());
                        currencies.add(nextData.getCurrency());
                        dates.add(nextData.getLastUpdate());
                    }
                        int counter = 0;
                        for(int i= 0; i < size; i++)
                        {
                            if(currencies.get(i).equalsIgnoreCase("Rupees"))
                            {
                                counter = i;
                            }
                        }
                Value = values.get(counter);
                Currency = currencies.get(counter);
                LastUpdate = dates.get(counter);
                s = new SharePrice();
                s.setValue(Value);
                s.setCurrency(Currency);
                s.setLastUpdate(LastUpdate);
                rupees.add(s);
                
                Iterator itr2 = rupees.iterator();
                while(itr2.hasNext())
                    {
                        nextData = (SharePrice) itr2.next();
                        System.out.println(nextData.getCurrency());
                        System.out.println(nextData.getValue());
                        System.out.println(nextData.getLastUpdate());
                    } 
                break;
            }
            default:
                System.out.println("There is no such option");
                break;
        }
    }

    private static java.util.List<org.netbeans.xml.schema.company.SharePrice> getAllShares() {
        org.myws.SharesWebService_Service service = new org.myws.SharesWebService_Service();
        org.myws.SharesWebService port = service.getSharesWebServicePort();
        return port.getAllShares();
    }

    private static java.util.List<org.netbeans.xml.schema.company.SharePrice> listHighestShareDetails() {
        org.myws.SharesWebService_Service service = new org.myws.SharesWebService_Service();
        org.myws.SharesWebService port = service.getSharesWebServicePort();
        return port.listHighestShareDetails();
    }

    private static java.util.List<org.netbeans.xml.schema.company.SharePrice> listDetailsForDollar() {
        org.myws.SharesWebService_Service service = new org.myws.SharesWebService_Service();
        org.myws.SharesWebService port = service.getSharesWebServicePort();
        return port.listDetailsForDollar();
    }

    private static java.util.List<org.netbeans.xml.schema.company.SharePrice> listDetailsForDinar() {
        org.myws.SharesWebService_Service service = new org.myws.SharesWebService_Service();
        org.myws.SharesWebService port = service.getSharesWebServicePort();
        return port.listDetailsForDinar();
    }

    private static java.util.List<org.netbeans.xml.schema.company.SharePrice> listDetailsForPounds() {
        org.myws.SharesWebService_Service service = new org.myws.SharesWebService_Service();
        org.myws.SharesWebService port = service.getSharesWebServicePort();
        return port.listDetailsForPounds();
    }

    private static java.util.List<org.netbeans.xml.schema.company.SharePrice> listDetailsForRupees() {
        org.myws.SharesWebService_Service service = new org.myws.SharesWebService_Service();
        org.myws.SharesWebService port = service.getSharesWebServicePort();
        return port.listDetailsForRupees();
    }
    
}
