/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.myws;

import ShareRequest.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.ejb.Stateless;

/**
 *
 * @author N0830182
 */
@WebService(serviceName = "SharesWebService")
@Stateless()
public class SharesWebService extends Thread{

    /**
     * This is a sample web service operation
     */
    static int shareprice =0;
    static int numShares = 54;
    @WebMethod(operationName = "getCompanyDetails")
    public List<Object> getCompanyDetails(){
        
        ShareRequest.Company input = new ShareRequest.Company();
        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(input.getClass().getPackage().getName());
            javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            input = (Company) unmarshaller.unmarshal(new java.io.File("H:\\Cloud Computing\\Coursework\\data.xml")); //NOI18N
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
        
        List<Object> CompanyDetails = new ArrayList<Object>();
        CompanyDetails.add(input.getCompanyName());
        CompanyDetails.add(input.getCompanySymbol());
        CompanyDetails.add(input.getSharesNo());
        return CompanyDetails;
    }
    
    @WebMethod(operationName = "getAllShares")
    public List<SharePrice> getAllShares() {
        
        ShareRequest.Company input = new ShareRequest.Company();
        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(input.getClass().getPackage().getName());
            javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            input = (Company) unmarshaller.unmarshal(new java.io.File("H:\\Cloud Computing\\Coursework\\data.xml")); //NOI18N
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
        
        List<SharePrice> mySharePrice = input.getShareDetails();
        return mySharePrice;
    }
    
    @WebMethod(operationName = "UpdateShareNo")
    public List<String> UpdateShareNo(){
        
        List<String> s = new ArrayList<String>();
        final int checks = 10; //number of share price readings
        final int delay = 2; //seconds between consecutive readings
        final int maxValue = 100; //maximum share value in the exchange
        final int BuyAgents = 10;
    
        SharesThread sth = new SharesThread(maxValue); //thread randomising share price
        sth.start();;
        
        BuyShares []bsth = new BuyShares[BuyAgents];
        for(int i =0; i<BuyAgents; i++)
        {
            bsth[i] = new BuyShares();
            bsth[i].start();
        }
        for (int i = 0; i< checks; i++)
        {
            try {
                s.add("Share price:" + shareprice + "Remaining shares:" + numShares);
                Thread.sleep(1000*delay);
            }
            catch(java.lang.InterruptedException ie){};
        }
        return s;
    }
    
    @WebMethod(operationName = "ListHighestShareDetails")
    public List<SharePrice> ListHighestShareDetails(){
        
        ShareRequest.Company input = new ShareRequest.Company();
         try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(input.getClass().getPackage().getName());
            javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            input = (Company) unmarshaller.unmarshal(new java.io.File("H:\\Cloud Computing\\Coursework\\data.xml")); //NOI18N
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
         
        List<SharePrice> list = input.getShareDetails();
        Iterator itr = list.iterator();
        SharePrice nextData;
        int size = list.size();
        List<Float> values = new ArrayList<Float>();
        List<String> currencies = new ArrayList<String>();
        List<String> dates = new ArrayList<String>();
        float Value = 0; String Currency = "", LastUpdate = "";
        
        List<SharePrice> highest = new ArrayList<SharePrice>();
        SharePrice s;
         while(itr.hasNext()){
                nextData = (SharePrice) itr.next();
                values.add(nextData.getValue());
                currencies.add(nextData.getCurrency());
                dates.add(nextData.getLastUpdate());
            }
                float max = Collections.max(values);
                int counter = 0;
                for(int i= 0; i < size; i++)
                {
                    if(values.get(i).equals(max))
                    {
                        counter = i;
                    }
                }
        Value = values.get(counter);
        Currency = currencies.get(counter);
        LastUpdate = dates.get(counter);
        s = new SharePrice();
        s.setValue(Value);
        s.setCurrency(Currency);
        s.setLastUpdate(LastUpdate);
        highest.add(s);
        return highest;
    }
    
    @WebMethod(operationName = "ListDetailsForDollar")
    public List<SharePrice> ListDetailsForDollar(){
        
        ShareRequest.Company input = new ShareRequest.Company();
        
        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(input.getClass().getPackage().getName());
            javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            input = (Company) unmarshaller.unmarshal(new java.io.File("H:\\Cloud Computing\\Coursework\\data.xml")); //NOI18N
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
        
        List<SharePrice> list = input.getShareDetails();
        Iterator itr = list.iterator();
        SharePrice nextData;
        int size = list.size();
        List<Float> values = new ArrayList<Float>();
        List<String> currencies = new ArrayList<String>();
        List<String> dates = new ArrayList<String>();
        float Value = 0; String Currency = "", LastUpdate = "";
        
        List<SharePrice> dollar = new ArrayList<SharePrice>();
        SharePrice s;
        while(itr.hasNext()){
                    nextData = (SharePrice) itr.next();
                    values.add(nextData.getValue());
                    currencies.add(nextData.getCurrency());
                    dates.add(nextData.getLastUpdate());
                }
                int counter = 0;
                for(int i= 0; i < size; i++)
                {
                    if(currencies.get(i).equalsIgnoreCase("Dollar"))
                    {
                        counter = i;
                    }
                }
        Value = values.get(counter);
        Currency = currencies.get(counter);
        LastUpdate = dates.get(counter);
        s = new SharePrice();
        s.setValue(Value);
        s.setCurrency(Currency);
        s.setLastUpdate(LastUpdate);
        dollar.add(s);
        return dollar;
    }
    
    @WebMethod(operationName = "ListDetailsForDinar")
    public List<SharePrice> ListDetailsForDinar(){
        
        ShareRequest.Company input = new ShareRequest.Company();
        
        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(input.getClass().getPackage().getName());
            javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            input = (Company) unmarshaller.unmarshal(new java.io.File("H:\\Cloud Computing\\Coursework\\data.xml")); //NOI18N
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
        
        List<SharePrice> list = input.getShareDetails();
        Iterator itr = list.iterator();
        SharePrice nextData;
        int size = list.size();
        List<Float> values = new ArrayList<Float>();
        List<String> currencies = new ArrayList<String>();
        List<String> dates = new ArrayList<String>();
        float Value = 0; String Currency = "", LastUpdate = "";
        
        List<SharePrice> dinar = new ArrayList<SharePrice>();
        SharePrice s;
        while(itr.hasNext()){
                    nextData = (SharePrice) itr.next();
                    values.add(nextData.getValue());
                    currencies.add(nextData.getCurrency());
                    dates.add(nextData.getLastUpdate());
                }
                int counter = 0;
                for(int i= 0; i < size; i++)
                {
                    if(currencies.get(i).equalsIgnoreCase("Dinar"))
                    {
                        counter = i;
                    }
                }
        Value = values.get(counter);
        Currency = currencies.get(counter);
        LastUpdate = dates.get(counter);
        s = new SharePrice();
        s.setValue(Value);
        s.setCurrency(Currency);
        s.setLastUpdate(LastUpdate);
        dinar.add(s);
        return dinar;
    }
    
    @WebMethod(operationName = "ListDetailsForPounds")
    public List<SharePrice> ListDetailsForPounds(){
        
        ShareRequest.Company input = new ShareRequest.Company();
        
        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(input.getClass().getPackage().getName());
            javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            input = (Company) unmarshaller.unmarshal(new java.io.File("H:\\Cloud Computing\\Coursework\\data.xml")); //NOI18N
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
        
        List<SharePrice> list = input.getShareDetails();
        Iterator itr = list.iterator();
        SharePrice nextData;
        int size = list.size();
        List<Float> values = new ArrayList<Float>();
        List<String> currencies = new ArrayList<String>();
        List<String> dates = new ArrayList<String>();
        float Value = 0; String Currency = "", LastUpdate = "";
        
        List<SharePrice> pounds = new ArrayList<SharePrice>();
        SharePrice s;
        while(itr.hasNext()){
                    nextData = (SharePrice) itr.next();
                    values.add(nextData.getValue());
                    currencies.add(nextData.getCurrency());
                    dates.add(nextData.getLastUpdate());
                }
                int counter = 0;
                for(int i= 0; i < size; i++)
                {
                    if(currencies.get(i).equalsIgnoreCase("Pounds"))
                    {
                        counter = i;
                    }
                }
        Value = values.get(counter);
        Currency = currencies.get(counter);
        LastUpdate = dates.get(counter);
        s = new SharePrice();
        s.setValue(Value);
        s.setCurrency(Currency);
        s.setLastUpdate(LastUpdate);
        pounds.add(s);
        return pounds;
    }
    
    @WebMethod(operationName = "ListDetailsForRupees")
    public List<SharePrice> ListDetailsForRupees(){
        
        ShareRequest.Company input = new ShareRequest.Company();
        
        try {
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(input.getClass().getPackage().getName());
            javax.xml.bind.Unmarshaller unmarshaller = jaxbCtx.createUnmarshaller();
            input = (Company) unmarshaller.unmarshal(new java.io.File("H:\\Cloud Computing\\Coursework\\data.xml")); //NOI18N
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
        
        List<SharePrice> list = input.getShareDetails();
        Iterator itr = list.iterator();
        SharePrice nextData;
        int size = list.size();
        List<Float> values = new ArrayList<Float>();
        List<String> currencies = new ArrayList<String>();
        List<String> dates = new ArrayList<String>();
        float Value = 0; String Currency = "", LastUpdate = "";
        
        List<SharePrice> rupees = new ArrayList<SharePrice>();
        SharePrice s;
        while(itr.hasNext()){
                    nextData = (SharePrice) itr.next();
                    values.add(nextData.getValue());
                    currencies.add(nextData.getCurrency());
                    dates.add(nextData.getLastUpdate());
                }
                int counter = 0;
                for(int i= 0; i < size; i++)
                {
                    if(currencies.get(i).equalsIgnoreCase("Rupees"))
                    {
                        counter = i;
                    }
                }
        Value = values.get(counter);
        Currency = currencies.get(counter);
        LastUpdate = dates.get(counter);
        s = new SharePrice();
        s.setValue(Value);
        s.setCurrency(Currency);
        s.setLastUpdate(LastUpdate);
        rupees.add(s);
        return rupees;
    }
}
    
    