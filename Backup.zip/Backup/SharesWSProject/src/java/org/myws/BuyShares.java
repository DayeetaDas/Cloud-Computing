/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.myws;
import java.util.concurrent.TimeUnit;
public class BuyShares extends Thread
{
   public BuyShares(){
       
   }
   static synchronized void BuyShares()
   {
       while(true)
       {
           if(SharesWebService.shareprice > price_toBuy && SharesWebService.numShares > 55)
           {
               System.out.println("Buying of $" + SharesWebService.shareprice);
               SharesWebService.numShares = SharesWebService.numShares - 5;
           }
           try{
               TimeUnit.MILLISECONDS.sleep(frequency);
           }catch(java.lang.InterruptedException ie){};
       }
   }
   public void run()
   {
       BuyShares();
   }
   public static final int price_toBuy = 54;
   public static long frequency = 100;
   
}
