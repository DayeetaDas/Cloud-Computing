/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author taha-m
 */
import java.io.File;
import java.util.Iterator;
import java.util.List;
import sharesOrder.*;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        sharesOrder.Company input = new sharesOrder.Company();
        
        input.setCompanyName("Google");
        input.setCompanySymbol("@@@@@");
        input.setSharesNo(54);
        
        List<SharePrice> values = input.getShareDetails();
        
        SharePrice s;
        s = new SharePrice();
        s.setCurrency("Dollar");
        s.setValue((float)38.8);
        s.setLastUpdate("09/01/2021");
        values.add(s);
        
        s = new SharePrice();
        s.setCurrency("Pounds");
        s.setValue((float)45.67);
        s.setLastUpdate("09/01/2021");
        values.add(s);
        
        s = new SharePrice();
        s.setCurrency("Dinar");
        s.setValue((float)40.15);
        s.setLastUpdate("09/01/2021");
        values.add(s);
        
        s = new SharePrice();
        s.setCurrency("Rupees");
        s.setValue((float)15.6);
        s.setLastUpdate("09/01/2021");
        values.add(s);
        
        try {            
            javax.xml.bind.JAXBContext jaxbCtx = javax.xml.bind.JAXBContext.newInstance(s.getClass().getPackage().getName());
            javax.xml.bind.Marshaller marshaller = jaxbCtx.createMarshaller();
            marshaller.setProperty(javax.xml.bind.Marshaller.JAXB_ENCODING, "UTF-8"); //NOI18N
            marshaller.setProperty(javax.xml.bind.Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            
            File file = new File("data.xml");
            //marshaller.marshal(input, System.out);
            marshaller.marshal(input,file);
        } catch (javax.xml.bind.JAXBException ex) {
            // XXXTODO Handle exception
            java.util.logging.Logger.getLogger("global").log(java.util.logging.Level.SEVERE, null, ex); //NOI18N
        }
    }

}
